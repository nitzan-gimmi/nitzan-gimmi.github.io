def text_to_ipa(text):
    return 'k.t.v'