def add_niqqud(word, gender='m'):
    return word+'ָ' if gender=='m' else word+'ת'