def generate_word(factors):
    return 'וּכָתְבוּם'