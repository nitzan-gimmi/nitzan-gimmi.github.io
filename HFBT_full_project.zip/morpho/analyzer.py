class MorphologicalAnalyzer:
    def analyze_word(self, word):
        return {'root':'כ.ת.ב','template':'פָּעַל','affixes':['ו','ם']}