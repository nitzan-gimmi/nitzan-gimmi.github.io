# HFBT - Hebrew Factor-Based Tokenization
גרסה מלאה של פרויקט HFBT עם ממשק AI בעברית.

כולל ניתוח מורפולוגי, TTS/STT, Vector of Will, מד רגשי חי.