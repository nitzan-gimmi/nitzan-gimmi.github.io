def compute_vow(text):
    return {'positive':1,'negative':0}