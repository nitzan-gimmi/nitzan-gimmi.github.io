🇮🇱✨ Davar Engine — השפה העברית מקבלת תקן רזוננס פתוח.

https://github.com/yourusername/davar-engine