#!/bin/bash
echo 'Deploying Davar Engine to Google Cloud Run...'