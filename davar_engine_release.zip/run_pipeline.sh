#!/bin/bash
echo 'Running OHS Quality Pipeline...'
python hfbt_batch_pipeline.py --source api