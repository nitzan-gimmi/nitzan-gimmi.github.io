
import React, { useEffect, useState } from "react";

export default function Journal() {
  const [entries, setEntries] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8000/journal")
      .then(res => res.json())
      .then(data => setEntries(data.journal));
  }, []);

  return (
    <div className="mt-6">
      <h2 className="font-bold text-xl mb-2">יומנאי</h2>
      {entries.length === 0 ? <p>עדיין אין רשומות.</p> :
      <ul className="list-disc ml-6">
        {entries.map((e, idx) => (
          <li key={idx}>
            <strong>{e.pipe}:</strong> {e.text} → {JSON.stringify(e.analysis)}
          </li>
        ))}
      </ul>
      }
    </div>
  );
}
