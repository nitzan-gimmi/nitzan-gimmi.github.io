
export default function Pipes({ pipe, setPipe }) {
  const options = [
    "The Linguistic Core",
    "The Technical Infrastructure",
    "The Community & The Internet"
  ];

  return (
    <div>
      <label className="font-semibold">בחר צינור:</label>
      <select
        value={pipe}
        onChange={(e) => setPipe(e.target.value)}
        className="border p-1 ml-2"
      >
        {options.map((o) => (
          <option key={o} value={o}>{o}</option>
        ))}
      </select>
    </div>
  );
}
