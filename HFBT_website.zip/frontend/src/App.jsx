
import React, { useState } from "react";
import Pipes from "./Pipes";
import Journal from "./Journal";

export default function App() {
  const [pipe, setPipe] = useState("The Linguistic Core");
  const [text, setText] = useState("");
  const [result, setResult] = useState(null);

  const handleSubmit = async () => {
    const resp = await fetch("http://localhost:8000/process_sentence", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({pipe, text})
    });
    const data = await resp.json();
    setResult(data.result);
    setText("");
  };

  return (
    <div className="p-6 font-sans">
      <h1 className="text-3xl font-bold mb-4">🌿 HFBT – הצינורות והיומנאי</h1>
      <Pipes pipe={pipe} setPipe={setPipe} />
      <textarea
        className="border p-2 w-full mt-2"
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="כתוב משפט בעברית..."
      />
      <button className="bg-green-500 text-white px-4 py-2 mt-2" onClick={handleSubmit}>
        שלח ל-HFBT
      </button>

      {result && (
        <div className="mt-4 p-2 border rounded">
          <p>רגש דומיננטי: {result.dominant}</p>
          <p>עוצמה: {Math.round(result.intensity * 100)}%</p>
          <p>וקטור רצון: {JSON.stringify(result.vector)}</p>
        </div>
      )}

      <Journal />
    </div>
  );
}
