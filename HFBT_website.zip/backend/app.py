
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import json
from hfbt_processor import analyze_text

app = FastAPI()

# Allow CORS for frontend (localhost:3000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

JOURNAL_FILE = "journal.json"

class UserInput(BaseModel):
    pipe: str
    text: str

@app.post("/process_sentence")
async def process_sentence(data: UserInput):
    result = analyze_text(data.text)
    try:
        with open(JOURNAL_FILE, "r", encoding="utf-8") as f:
            journal = json.load(f)
    except FileNotFoundError:
        journal = []
    entry = {"pipe": data.pipe, "text": data.text, "analysis": result}
    journal.append(entry)
    with open(JOURNAL_FILE, "w", encoding="utf-8") as f:
        json.dump(journal, f, ensure_ascii=False, indent=2)
    return {"status": "ok", "result": result}

@app.get("/journal")
async def get_journal():
    try:
        with open(JOURNAL_FILE, "r", encoding="utf-8") as f:
            journal = json.load(f)
    except FileNotFoundError:
        journal = []
    return {"journal": journal}
