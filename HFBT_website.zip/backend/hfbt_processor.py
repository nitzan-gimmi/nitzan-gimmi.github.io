
from dataclasses import dataclass
from typing import Dict

@dataclass
class EmotionResult:
    dominant: str
    intensity: float
    vector: Dict[str, float]

def analyze_text(text: str) -> Dict:
    positive_words = ["טוב", "שמח", "אהבה", "נהדר", "מצוין"]
    negative_words = ["עצוב", "רע", "כואב", "קשה", "מאוכזב"]

    score = 0
    for word in text.split():
        if any(p in word for p in positive_words):
            score += 1
        if any(n in word for n in negative_words):
            score -= 1

    dominant = "positive" if score > 0 else "negative" if score < 0 else "neutral"
    intensity = min(abs(score) / 3, 1.0)
    vector = {"positive": max(score, 0), "negative": max(-score, 0)}

    return {"dominant": dominant, "intensity": intensity, "vector": vector}
